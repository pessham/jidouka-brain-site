"""
Wikipedia「自動化」ページのタイトルと冒頭の説明文（リード文）を取得して result.txt に保存する。
"""

from playwright.sync_api import sync_playwright
from pathlib import Path
import datetime

# 「自動化」で開くと Wikipedia 側で「自動」の記事に転送される。取得されるタイトルは「自動」になる。
TARGET_URL = "https://ja.wikipedia.org/wiki/%E8%87%AA%E5%8B%95%E5%8C%96"
OUTPUT_FILE = Path(__file__).parent / "result.txt"
SCREENSHOT_DIR = Path(__file__).parent / "screenshots"


def main():
    SCREENSHOT_DIR.mkdir(exist_ok=True)

    with sync_playwright() as p:
        browser = p.chromium.launch(headless=False)
        page = browser.new_page()

        # ページを開く
        print(f"ページを開いています: {TARGET_URL}")
        page.goto(TARGET_URL, wait_until="domcontentloaded")

        # 本文エリアが表示されるまで待つ
        page.wait_for_selector("#mw-content-text", timeout=10_000)
        print("ページの読み込み完了")
        page.wait_for_timeout(800)

        # ページタイトルを取得＆ハイライト
        title_el = page.locator("#firstHeading")
        title_el.evaluate("el => el.style.cssText += 'background:#ffe066; outline:3px solid #f0a500; transition:all 0.3s;'")
        page.wait_for_timeout(1000)
        title = title_el.inner_text().strip()
        print(f"タイトル: {title}")
        page.wait_for_timeout(600)

        # リード文（冒頭の段落）を取得
        # 冒頭の3段落までに絞る。全部拾うと、記事の長さによっては色づけが延々と続く。
        lead_paragraphs = page.locator(
            "#mw-content-text .mw-parser-output p"
        ).all()[:3]

        lead_lines = []
        for p_el in lead_paragraphs:
            text = p_el.inner_text().strip()
            if not text:
                continue
            # 段落をスクロールして見えるようにしてからハイライト
            p_el.scroll_into_view_if_needed()
            p_el.evaluate("el => el.style.cssText += 'background:#e8f4ff; outline:2px solid #4a9eff; transition:all 0.3s;'")
            page.wait_for_timeout(700)
            lead_lines.append(text)

        # 取得できたか確認
        if not lead_lines:
            page.screenshot(path=str(SCREENSHOT_DIR / "error_no_text.png"))
            print("エラー: 本文が取得できませんでした。スクリーンショットを保存しました。")
            browser.close()
            return

        print(f"段落を {len(lead_lines)} 件取得しました")

        # result.txt に書き出す
        timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        lines = [
            f"取得日時: {timestamp}",
            f"URL: {TARGET_URL}",
            "",
            f"【タイトル】{title}",
            "",
            "【説明文】",
        ] + lead_lines

        OUTPUT_FILE.write_text("\n\n".join(lines), encoding="utf-8")

        # ファイルが書き込まれたか確認
        if OUTPUT_FILE.exists() and OUTPUT_FILE.stat().st_size > 0:
            print(f"\n保存完了: {OUTPUT_FILE}")
        else:
            print("エラー: ファイルの書き込みに失敗しました。")
            page.screenshot(path=str(SCREENSHOT_DIR / "error_write_failed.png"))

        input("\n--- Enterキーでブラウザを閉じます ---")
        browser.close()


if __name__ == "__main__":
    main()
