@echo off
chcp 65001 >nul
rem ダブルクリックで Wikipedia デモを起動するランチャー（Windows用）

cd /d "%~dp0"

echo ==============================
echo   はじめての自動化（Wikipedia 取得デモ）
echo ==============================
echo.

set "PYCMD="
where py >nul 2>nul && set "PYCMD=py -3"
if not defined PYCMD where python >nul 2>nul && set "PYCMD=python"
if not defined PYCMD (
  echo Python 3が見つかりません。python.org からインストールしてください。
  pause
  exit /b 1
)

set VENV_DIR=.venv

if not exist "%VENV_DIR%" (
  echo [準備] 初回セットアップを行います（1〜2分かかります）...
  echo.

  %PYCMD% -m venv "%VENV_DIR%"
  if errorlevel 1 (
    echo venvの作成に失敗した。Pythonがインストールされているか確認すること。
    pause
    exit /b 1
  )
  "%VENV_DIR%\Scripts\pip.exe" install playwright -q
  "%VENV_DIR%\Scripts\playwright.exe" install chromium

  echo.
  echo [準備] セットアップ完了
  echo.
)

echo [実行] ブラウザを起動します...
echo.
"%VENV_DIR%\Scripts\python.exe" main.py

echo.
echo 終了しました。このウィンドウは閉じて構いません。
pause
