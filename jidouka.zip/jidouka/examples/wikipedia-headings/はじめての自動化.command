#!/bin/zsh
# ダブルクリックで Wikipedia デモを起動するランチャー

# このファイルがある場所に移動
cd "$(dirname "$0")"

echo "=============================="
echo "  はじめての自動化（Wikipedia 取得デモ）"
echo "=============================="
echo ""

VENV_DIR=".venv"

# 初回のみ：仮想環境と Playwright をセットアップ
if [ ! -d "$VENV_DIR" ]; then
  echo "[準備] 初回セットアップを行います（1〜2分かかります）..."
  echo ""

  python3 -m venv "$VENV_DIR"
  "$VENV_DIR/bin/pip" install playwright -q
  "$VENV_DIR/bin/playwright" install chromium

  echo ""
  echo "[準備] セットアップ完了"
  echo ""
fi

# スクリプトを実行
echo "[実行] ブラウザを起動します..."
echo ""
"$VENV_DIR/bin/python3" main.py

echo ""
echo "終了しました。このウィンドウは閉じて構いません。"
