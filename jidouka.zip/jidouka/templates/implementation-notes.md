# implementation-notes.md

## このファイルについて

Claude Code がこの自動化を作る途中で、判断や計画からのズレを記録するファイルである。
「動いたはず」で終わらせず、何を確認して成功と判断したかをここに残す。

## 作業概要

## 計画通りに進んだこと

## 計画から外れたこと

## Deviations

（計画から外れた理由と、選んだ対応を書く）

## Edge Cases

（見つけた端のケースと、その扱い）

## Conservative Choices

（迷ったときに保守的に選んだ内容と理由を書く）

## Files Changed

（変更したファイルのパス一覧）

## Checks Performed

（実施した確認・テストと、その結果）

## Checks Not Performed

（確認できなかったことを正直に書く。「たぶん大丈夫」で埋めない）

## Open Questions

（未解決のまま残った疑問）

## Next Attempt Notes

（次回、最初から指示に入れるべきこと・最初に確認すべきことを書く）
