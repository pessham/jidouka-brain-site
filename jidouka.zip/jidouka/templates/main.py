"""
main.py — ブラウザ自動化テンプレート（jidouka）

このファイルは、Claude Code が新しい自動化を作るときの「土台」である。
ゼロから書くのではなく、これをコピーして process_one_item() を書き換えて使う。

このテンプレートが守っていること:
  - 「操作したか」ではなく「結果が変わったか」を確認する
  - 1件動く形から作り、最初から多機能にしない
  - 失敗したらスクリーンショットを残し、ブラウザをすぐ閉じない
  - 公開・送信・削除・支払いの最後の1クリックは人間に残す

config.json と .env が無くても、このファイルはサンプル設定（Wikipedia）で動く。
自分の自動化にするときは、config.example.json と env.example をコピーして書き換える。
"""

from __future__ import annotations

import json
import logging
import os
import sys
from datetime import datetime
from pathlib import Path

try:
    from dotenv import load_dotenv
except ImportError:
    load_dotenv = None  # .env は必須ではない。無ければ環境変数だけで進む

try:
    from playwright.sync_api import Page, TimeoutError as PlaywrightTimeoutError, sync_playwright
except ImportError:
    print("Playwright が入っていない。run.command（Windowsは run.bat）を実行すると自動でインストールされる。", file=sys.stderr)
    print("手動で入れる場合: pip install -r requirements.txt && playwright install chromium", file=sys.stderr)
    sys.exit(1)


# ============================================================
# パス（ここは基本的に変更しなくてよい）
# ============================================================
BASE_DIR = Path(__file__).parent
CONFIG_FILE = BASE_DIR / "config.json"
ENV_FILE = BASE_DIR / ".env"
LOGS_DIR = BASE_DIR / "logs"
SCREENSHOTS_DIR = BASE_DIR / "screenshots"
DATA_DIR = BASE_DIR / "data"
PROCESSED_FILE = DATA_DIR / "processed.json"

for _dir in (LOGS_DIR, SCREENSHOTS_DIR, DATA_DIR):
    _dir.mkdir(exist_ok=True)


# ============================================================
# 設定のデフォルト値
# config.json が無い場合、このデフォルト値だけで動作確認ができる。
# 本番の自動化にするときは config.example.json をコピーして書き換える。
# ============================================================
DEFAULT_CONFIG = {
    "headless": False,
    "target_urls": [
        "https://ja.wikipedia.org/wiki/Playwright",
    ],
}


# ============================================================
# ログ設定
# logs/YYYY-MM-DD.log に記録しつつ、画面にも表示する
# ============================================================
def setup_logging() -> logging.Logger:
    log_file = LOGS_DIR / f"{datetime.now().strftime('%Y-%m-%d')}.log"
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(levelname)s] %(message)s",
        handlers=[
            logging.FileHandler(log_file, encoding="utf-8"),
            logging.StreamHandler(),
        ],
    )
    return logging.getLogger("jidouka")


log = setup_logging()


# ============================================================
# 設定読み込み
# config.json と .env は、両方とも「無くても止まらない」設計にしてある。
# 無い場合はデフォルト値で動くが、ログに警告を出して気づけるようにする。
# ============================================================
def load_config() -> dict:
    if not CONFIG_FILE.exists():
        log.warning(
            "config.json が見つからない。config.example.json をコピーして "
            "config.json を作ると、自分の対象に合わせて動かせる。"
            "今回はサンプル設定（Wikipedia）で動く。"
        )
        return dict(DEFAULT_CONFIG)

    with open(CONFIG_FILE, encoding="utf-8") as f:
        user_config = json.load(f)

    config = dict(DEFAULT_CONFIG)
    config.update(user_config)
    return config


def load_env() -> None:
    if load_dotenv is None:
        log.warning("python-dotenv が入っていない。requirements.txt を入れ直すと解決する。")
        return
    if not ENV_FILE.exists():
        log.info(".env が見つからない。ログイン情報が要らない自動化なら、このままでよい。")
        return
    load_dotenv(ENV_FILE)
    log.info(".env を読み込んだ。")


def get_secret(key: str, required: bool = False) -> str | None:
    """.env や環境変数からIDやパスワードを取り出す。コードに直接値を書かないこと。"""
    value = os.getenv(key)
    if required and not value:
        log.error(f"{key} が .env に設定されていない。env.example を参考に .env を作ること。")
        sys.exit(1)
    return value


# ============================================================
# 途中再開の土台
# 処理済みのIDを data/processed.json に記録し、次回はそこから飛ばす。
# ============================================================
def load_processed() -> set[str]:
    if not PROCESSED_FILE.exists():
        return set()
    with open(PROCESSED_FILE, encoding="utf-8") as f:
        return set(json.load(f))


def mark_processed(processed_ids: set[str], item_id: str) -> None:
    processed_ids.add(item_id)
    with open(PROCESSED_FILE, "w", encoding="utf-8") as f:
        json.dump(sorted(processed_ids), f, ensure_ascii=False, indent=2)


# ============================================================
# 失敗時の記録
# ============================================================
def save_error_screenshot(page: Page, reason: str) -> Path:
    timestamp = datetime.now().strftime("%Y-%m-%d_%H%M%S")
    safe_reason = "".join(c if c.isalnum() or c in "_-" else "_" for c in reason)[:50]
    path = SCREENSHOTS_DIR / f"{timestamp}_{safe_reason}.png"
    try:
        page.screenshot(path=str(path), full_page=True)
        log.error(f"スクリーンショットを保存した: {path}")
    except Exception as exc:  # スクショ自体が失敗しても、ログだけは残す
        log.error(f"スクリーンショット保存にも失敗した: {exc}")
    return path


def pause_for_human(message: str) -> None:
    """ブラウザを閉じずに待つ。画面を見て何が起きたか確認してから Enter を押す。"""
    print()
    print("=" * 60)
    print(f"[要確認] {message}")
    print("ブラウザの画面を見て、状況を確認すること。")
    print("=" * 60)
    try:
        input("確認したら Enter を押してください: ")
    except EOFError:
        pass


# ============================================================
# 結果確認ヘルパー（このテンプレートの一番大事な部分）
# 「クリックした」「入力した」だけで OK にしない。
# 画面が実際に変わったか、値が実際に入ったかをここで確認する。
# ============================================================
def confirm_click_changed(page: Page, before_snapshot: str, timeout_ms: int = 5000) -> bool:
    """
    クリック前に控えておいた状態（page.url など）と、クリック後の状態を比べる。

    使い方の例:
        before = page.url
        page.get_by_role("button", name="次へ").click()
        if not confirm_click_changed(page, before):
            ...失敗として扱う
    """
    try:
        page.wait_for_timeout(300)  # 画面反映のための一瞬の余裕
        page.wait_for_load_state("domcontentloaded", timeout=timeout_ms)
    except PlaywrightTimeoutError:
        pass  # ページ遷移を伴わないクリック（モーダル開閉など）もあるので、ここでは失敗にしない

    after_snapshot = page.url
    changed = after_snapshot != before_snapshot
    if not changed:
        log.warning(f"クリック後も状態が変わっていない: {before_snapshot}")
    return changed


def confirm_text_appeared(page: Page, expected_text: str, timeout_ms: int = 8000) -> bool:
    """クリックや保存のあと、期待する文言（完了表示など）が実際に出たかを確認する。"""
    try:
        page.get_by_text(expected_text).first.wait_for(state="visible", timeout=timeout_ms)
        log.info(f"確認OK: 「{expected_text}」が表示された")
        return True
    except PlaywrightTimeoutError:
        log.warning(f"確認NG: 「{expected_text}」が表示されなかった")
        return False


def confirm_input_value(locator, expected_value: str) -> bool:
    """
    入力欄に文字を入れたあと、実際に反映されているかを読み直して確認する。

    使い方の例:
        box = page.get_by_label("氏名")
        box.fill("山田太郎")
        if not confirm_input_value(box, "山田太郎"):
            ...失敗として扱う
    """
    actual_value = locator.input_value()
    matched = actual_value == expected_value
    if not matched:
        log.warning(f"入力値が一致しない: 期待='{expected_value}' 実際='{actual_value}'")
    return matched


# ============================================================
# 1件処理する関数 ← ここを書き換えて使う
# ============================================================
def process_one_item(page: Page, item: dict) -> bool:
    """
    1件分の自動化処理。今はデモとして「指定URLを開いてタイトルを取得する」だけになっている。
    実際の自動化にするときは、この関数の中身を対象サイトの操作に書き換える。

    戻り値: 成功したら True、失敗したら False
    """
    url = item["url"]
    log.info(f"処理開始: {url}")

    page.goto(url, wait_until="domcontentloaded", timeout=20000)

    # --- ここから「結果を確認する」書き方の例 ---
    # page.goto() を呼んだだけで満足しない。ページが実際に開けたかを見出しで確認する。
    heading = page.locator("h1").first
    try:
        heading.wait_for(state="visible", timeout=8000)
    except PlaywrightTimeoutError:
        log.error(f"見出し(h1)が表示されなかった: {url}")
        save_error_screenshot(page, "見出し表示なし")
        return False

    title_text = heading.inner_text().strip()
    log.info(f"取得したタイトル: {title_text}")

    # ------------------------------------------------------------
    # ここから先は人間が確認する箇所の例（公開・送信・削除・支払いの直前）
    # 実際の自動化で「送信」「公開」「削除」「支払い」ボタンを押す処理を書くときは、
    # 自動でクリックせず、下のように一時停止して人間の最後の1クリックに委ねること。
    #
    # 例:
    #   page.get_by_role("button", name="下書き保存").click()
    #   confirm_text_appeared(page, "下書きを保存しました")
    #   pause_for_human("下書きを保存した。内容を確認し、公開は自分の手で行うこと。")
    #   # ここで page.get_by_role("button", name="公開").click() は書かない
    # ------------------------------------------------------------

    return True


# ============================================================
# メイン処理
# 1件だけ動かす → 複数件 → 途中再開、の順で育てる前提の骨格になっている。
# ============================================================
def main() -> int:
    log.info("=" * 50)
    log.info("自動化を開始する")
    log.info("=" * 50)

    load_env()
    config = load_config()
    processed_ids = load_processed()

    items = [{"id": url, "url": url} for url in config["target_urls"]]
    log.info(f"対象件数: {len(items)}件（うち処理済み: {len(processed_ids)}件）")

    success_count = 0
    fail_count = 0

    with sync_playwright() as playwright:
        browser = playwright.chromium.launch(headless=config.get("headless", False))
        context = browser.new_context()
        page = context.new_page()

        try:
            for item in items:
                if item["id"] in processed_ids:
                    log.info(f"スキップ（処理済み）: {item['id']}")
                    continue

                try:
                    ok = process_one_item(page, item)
                except Exception as exc:  # 想定外の失敗も、必ず記録してから止まる
                    log.error(f"想定外のエラー: {item['id']} — {exc}")
                    save_error_screenshot(page, "想定外エラー")
                    pause_for_human(f"{item['id']} の処理中にエラーが発生した。ログを確認すること。")
                    fail_count += 1
                    continue

                if ok:
                    mark_processed(processed_ids, item["id"])
                    success_count += 1
                    log.info(f"完了: {item['id']}")
                else:
                    fail_count += 1
                    pause_for_human(f"{item['id']} の処理に失敗した。スクリーンショットを確認すること。")

        finally:
            browser.close()

    log.info("=" * 50)
    log.info(f"終了: 成功 {success_count}件 / 失敗 {fail_count}件")
    log.info("=" * 50)

    return 0 if fail_count == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
