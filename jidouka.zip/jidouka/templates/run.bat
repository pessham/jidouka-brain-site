@echo off
chcp 65001 >nul
rem ダブルクリックで実行するランチャー（Windows用）

cd /d "%~dp0"

set "PYCMD="
where py >nul 2>nul && set "PYCMD=py -3"
if not defined PYCMD where python >nul 2>nul && set "PYCMD=python"
if not defined PYCMD (
  echo Python 3が見つかりません。python.org からインストールしてください。
  pause
  exit /b 1
)

if not exist "venv" (
  echo 初回セットアップをする。少し時間がかかる。
  %PYCMD% -m venv venv
  if errorlevel 1 (
    echo venvの作成に失敗した。Pythonがインストールされているか確認すること。
    pause
    exit /b 1
  )
  venv\Scripts\python.exe -m pip install --upgrade pip
  venv\Scripts\pip.exe install -r requirements.txt
  if errorlevel 1 (
    echo ライブラリのインストールに失敗した。requirements.txtとネット接続を確認すること。
    pause
    exit /b 1
  )
  venv\Scripts\playwright.exe install chromium
  if errorlevel 1 (
    echo Playwrightのブラウザインストールに失敗した。ネット接続を確認すること。
    pause
    exit /b 1
  )
  echo セットアップ完了
)

venv\Scripts\python.exe main.py

echo.
echo 完了した。ログは logs フォルダ、失敗時の証拠は screenshots フォルダを確認すること。
pause
