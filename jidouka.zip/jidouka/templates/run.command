#!/bin/bash
# ダブルクリックで実行するランチャー（Mac用）

cd "$(dirname "$0")"

if [ ! -d "venv" ]; then
  echo "初回セットアップをする。少し時間がかかる。"
  python3 -m venv venv
  source venv/bin/activate
  pip install --upgrade pip
  pip install -r requirements.txt
  playwright install chromium
  echo "セットアップ完了"
else
  source venv/bin/activate
fi

python3 main.py

echo ""
echo "完了した。ログは logs/ フォルダ、失敗時の証拠は screenshots/ フォルダを確認すること。"
read -p "Enterで閉じます..."
